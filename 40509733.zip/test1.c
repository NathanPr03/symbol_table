int main ( )
{
	int x = 3 ;
	int y = 5 ;
	int z = x + y ;
	int g = x * y ;
	int f = x - y ;
	int a ;
	if ( z > 7 )
	{
		a = 1 ;
	}
	else
	{
		a = 2 ;
	}
	a ++ ;
	return 0 ;
}